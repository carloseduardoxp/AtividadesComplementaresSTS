insert into Aluno values (59320492,'carlos eduardo');
insert into Aluno values (11113,'breno');